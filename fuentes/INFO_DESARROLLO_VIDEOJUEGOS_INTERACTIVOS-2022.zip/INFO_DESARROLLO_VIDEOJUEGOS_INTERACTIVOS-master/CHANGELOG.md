# Registro de cambios

Estos son los cambios hechos en la ECORED-BASE-INFO-2021

## 1.1.0 - 25-05-2021

