module.exports = 'Desarrollo de videojuegos y entornos interactivos'
